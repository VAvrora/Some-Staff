angular.module('ionicApp', ['ionic'])

.config(function($stateProvider, $urlRouterProvider) {

  $stateProvider
    .state('signin', {
      url: '/sign-in',
      templateUrl: 'sign-in.html',
      controller: 'SignInCtrl'
    })
    .state('signup', {
      url: '/sign-up',
      templateUrl: 'sign-up.html'
    })
      .state('myrequests', {
      url: '/myrequests',
      templateUrl: 'myrequests.html'
    })
	
	///////////////////////
	.state('messages', {
      url: '/messages',
      templateUrl: 'messages.html'
    })
	
	.state('drivingHistory', {
      url: '/drivingHistory',
      templateUrl: 'drivingHistory.html'
    })
	
	.state('personalDetails', {
      url: '/personalDetails',
      templateUrl: 'personalDetails.html'
    })
	

// ----> Just something I added <---
    //   .state('myrequests', {
    //   url: '/myrequests',
    //   templateUrl: 'myrequests.html',
    //   controller: 'MyRequestsCtrl'
    // })


    .state('tabs', {
      url: '/tab',
      abstract: true,
      templateUrl: 'tabs.html'
    })
    .state('tabs.home', {
      url: '/home',
      views: {
        'home-tab': {
          templateUrl: 'home.html',
          controller: 'HomeTabCtrl'
        }
      }
    })
    .state('tabs.rider', {
      url: '/rider',
      views: {
        'rider-tab': {
          templateUrl: 'rider.html',
          controller: 'RiderCtrl'
        }
      }
    })
	.state('tabs.about', {
      url: '/about',
      views: {
        'about-tab': {
          templateUrl: 'about.html',
      //    controller: 'RiderCtrl'
        }
      }
    })
    .state('tabs.driver', {
      url: '/driver',
      views: {
        'driver-tab': {
          templateUrl: 'driver.html',
          controller: 'DriverCtrl'
        }
      }
    })

    ///// continue


   $urlRouterProvider.otherwise('/sign-in');

})


.controller('SignInCtrl', function($scope, $state) {  
  $scope.signIn = function(user) { // ng-click function
    console.log('Sign-In', user);

    // send those details to server

    $state.go("tabs.home");
  };
})


.controller('RiderCtrl', function($scope, $state) {  
  $scope.rider = function(newride) { // ng-click function
    console.log('rider', newride);
    $state.go("tabs.home");
  };
})



.controller('MyRequestsCtrl', function($scope, $state) {  
  // $scope.rider = function(newride) { // ng-click function
  //   console.log('rider', newride);
  //   $state.go("tabs.home");
  // };

  console.log("myReqCtrl");

})





.controller('DriverCtrl', function($scope, $state) {  
  $scope.driver = function(trip) { // ng-click function
    console.log('driver', trip);
    $state.go("tabs.home");
  };
})

.controller('HomeTabCtrl', function($scope) {
  console.log('HomeTabCtrl');
});













